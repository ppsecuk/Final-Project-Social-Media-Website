/*
MySQL Backup
Database: marlen02_socialm
Backup Time: 2019-12-08 15:50:14
*/

SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS `marlen02_socialm`.`comments`;
DROP TABLE IF EXISTS `marlen02_socialm`.`friends`;
DROP TABLE IF EXISTS `marlen02_socialm`.`hibernate_sequence`;
DROP TABLE IF EXISTS `marlen02_socialm`.`likes`;
DROP TABLE IF EXISTS `marlen02_socialm`.`posts`;
DROP TABLE IF EXISTS `marlen02_socialm`.`users`;
CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `content` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `comments_posts_id_fk` (`post_id`),
  KEY `comments_users_user_id_fk` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
CREATE TABLE `friends` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_user_id` int(11) NOT NULL,
  `second_user_id` int(11) NOT NULL,
  `status` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `friends_users_user_id_fk` (`first_user_id`),
  KEY `friends_users_user_id_fk_2` (`second_user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;
CREATE TABLE `hibernate_sequence` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `likes_posts_id_fk` (`post_id`),
  KEY `likes_users_user_id_fk` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
CREATE TABLE `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `content` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `posts_users_user_id_fk` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `dob` date NOT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `status` varchar(20) NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `users_email_uindex` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
BEGIN;
LOCK TABLES `marlen02_socialm`.`comments` WRITE;
DELETE FROM `marlen02_socialm`.`comments`;
INSERT INTO `marlen02_socialm`.`comments` (`id`,`user_id`,`post_id`,`date`,`content`) VALUES (1, 3, 1, '2019-12-07 09:45:31', 'sample comment'),(2, 3, 3, '2019-12-07 10:58:09', 'comment 1'),(3, 3, 3, '2019-12-07 11:04:12', 'comment 2'),(4, 3, 3, '2019-12-07 11:21:32', 'vfdvvd'),(5, 3, 3, '2019-12-07 11:22:06', 'dffsda'),(6, 3, 5, '2019-12-07 11:36:37', 'test comment'),(7, 3, 10, '2019-12-07 14:03:28', 'frefe'),(8, 3, 11, '2019-12-08 11:34:27', 'test comment'),(9, 1, 12, '2019-12-08 14:02:32', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has su'),(10, 3, 1, '2019-12-08 14:19:27', 'Comment 2'),(11, 7, 3, '2019-12-08 15:39:54', 'test comment from Julia !!');
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `marlen02_socialm`.`friends` WRITE;
DELETE FROM `marlen02_socialm`.`friends`;
INSERT INTO `marlen02_socialm`.`friends` (`id`,`first_user_id`,`second_user_id`,`status`) VALUES (18, 5, 7, 'APPROVED'),(17, 7, 5, 'APPROVED'),(3, 1, 2, 'APPROVED'),(4, 2, 1, 'APPROVED'),(5, 1, 3, 'APPROVED'),(6, 3, 1, 'APPROVED'),(7, 1, 4, 'APPROVED'),(8, 4, 1, 'APPROVED'),(9, 1, 5, 'APPROVED'),(10, 5, 1, 'APPROVED'),(12, 3, 2, 'APPROVED'),(13, 2, 3, 'APPROVED'),(14, 3, 4, 'APPROVED'),(19, 7, 5, 'APPROVED'),(16, 4, 3, 'APPROVED'),(20, 7, 3, 'APPROVED'),(21, 3, 7, 'APPROVED'),(22, 7, 5, 'APPROVED'),(23, 7, 3, 'APPROVED');
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `marlen02_socialm`.`hibernate_sequence` WRITE;
DELETE FROM `marlen02_socialm`.`hibernate_sequence`;
INSERT INTO `marlen02_socialm`.`hibernate_sequence` (`next_val`) VALUES (1),(1);
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `marlen02_socialm`.`likes` WRITE;
DELETE FROM `marlen02_socialm`.`likes`;
INSERT INTO `marlen02_socialm`.`likes` (`id`,`user_id`,`post_id`) VALUES (4, 3, 3),(3, 3, 4),(5, 3, 11),(6, 3, 1),(7, 7, 3);
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `marlen02_socialm`.`posts` WRITE;
DELETE FROM `marlen02_socialm`.`posts`;
INSERT INTO `marlen02_socialm`.`posts` (`id`,`user_id`,`date`,`content`) VALUES (1, 1, '2019-11-28 00:00:00', 'Привет!'),(2, 1, '2019-11-28 00:00:00', 'Пока!'),(3, 3, '2019-11-30 14:49:33', 'This is a sample post from db'),(4, 3, '2019-11-30 14:49:36', 'This is a sample post from db'),(5, 3, '2019-11-30 14:49:37', 'This is a sample post from db'),(6, 3, '2019-11-30 14:49:39', 'This is a sample post from db'),(7, 3, '2019-11-30 14:49:40', 'This is a sample post from db'),(8, 3, '2019-11-30 14:49:41', 'This is a sample post from db'),(9, 3, '2019-11-30 14:49:46', 'This is a sample post from db'),(10, 3, '2019-11-30 14:50:05', 'This is a sample post from dbThis is a sample post from dbThis is a sample post from dbThis is a sample post from dbThis is a sample post from dbThis is a sample post from dbThis is a sample post from dbThis is a sample post from dbThis is a sample post f'),(11, 6, '2019-11-30 14:50:05', 'This is a sample post from dbThis is a sample post from dbThis is a sample post from dbThis is a sample post from dbThis is a sample post from dbThis is a sample post from dbThis is a sample post from dbThis is a sample post from dbThis is a sample post f'),(12, 1, '2019-12-08 14:05:25', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has su'),(13, 6, '2019-12-08 14:05:46', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, co'),(14, 3, '2019-12-08 14:06:15', 'Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one '),(15, 4, '2019-12-08 14:09:08', 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, yo'),(16, 7, '2019-12-08 15:26:29', 'post content from   UI'),(17, 7, '2019-12-08 15:30:50', 'Post 2'),(18, 7, '2019-12-08 15:41:09', 'New post from Julia');
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `marlen02_socialm`.`users` WRITE;
DELETE FROM `marlen02_socialm`.`users`;
INSERT INTO `marlen02_socialm`.`users` (`user_id`,`password`,`first_name`,`last_name`,`email`,`gender`,`dob`,`profile_picture`,`status`) VALUES (1, '123', 'Bogdan', 'Tereshuk', 'test@gmail.com', 'Male', '2019-10-30', '', 'ACTIVE'),(2, '123', 'Evgeniy', 'Sethuck', 'test2@gmail.com', 'Male', '2019-10-30', '', 'ACTIVE'),(3, '123', 'Pavel', 'Psecuk', 'pavel@gmail.com', 'Male', '2019-11-26', '', 'ACTIVE'),(4, '123', 'Paul', 'Johnson', '12@gmail.com', 'Female', '2019-11-04', '', 'ACTIVE'),(5, '123', 'John', 'Doe', '123@gmail.com', 'Male', '2019-11-04', '', 'ACTIVE'),(6, '123', 'Pamela', 'Anderson', 'pamela@gmail.com', 'Female', '1990-10-02', '6a0a1a29-3c4d-4165-9e63-760c19bc9c53.pamela.jpg', 'ACTIVE'),(7, '123', 'Julia', 'Jackson', 'julia@gmail.com', 'Female', '1999-12-09', '3dea21cd-9a72-4bf3-9b2a-5819442d4037.girl.jpeg', 'INACTIVE'),(8, '123', 'Julia', 'Stanley', 'julia2@mail.com', 'Female', '2008-12-16', '5819442d4037.girl.jpeg', 'ACTIVE');
UNLOCK TABLES;
COMMIT;
